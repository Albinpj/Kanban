from odoo import api, fields, models


class ContactsDocuments(models.Model):
    _name = "contacts.documents"
    _description = "Contacts Documents"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    # type = fields.Selection(selection_add=[
    #     ('file', "File"), ])
    file_content = fields.Binary(string='File Content', attachment=True, required=True)
    file_name = fields.Char()
    extension = fields.Char(string='Extension', compute='upload_document_file')

    mime_type = fields.Char(string="Mime  Type")

    def upload_document_file(self):
        # print(self.extension, 'ji')
        for rec in self:
            rec.sudo().write({
                'extension': rec.file_name.split(".")[1]
            })
            self.mime_type = 'image/' + rec.extension
