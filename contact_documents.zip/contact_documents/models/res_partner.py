from odoo import api, fields, models


class PartnerDocuments(models.Model):
    _inherit = 'res.partner'

    document_count = fields.Char(compute='total_document_count')

    @api.depends('document_count')
    def total_document_count(self):
        for record in self:
            record.document_count = self.env[
                'contacts.documents'].search_count([])

    def partner_documents(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Documents',
            'view_mode': 'kanban,form',
            'res_model': 'contacts.documents',
            # 'domain': [('driver_id', '=', self.id)],
            'context': "{'create': True}"
        }
