from . import documents
from . import res_partner
