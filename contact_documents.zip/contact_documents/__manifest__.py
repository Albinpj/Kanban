{
    'name': 'Contacts Documents',
    'version': '16.0.1.0.0',
    'summary': """Contacts Documents""",
    'description': """Contacts Documents""",
    'author': 'Cybrosys Techno Solutions',
    'company': 'Cybrosys Techno Solutions',
    'website': "https://www.cybrosys.com",
    'maintainer': 'Cybrosys Techno Solutions',
    'depends': ['base', 'contacts'],
    'data': [
        'security/ir.model.access.csv',
        'views/res_partner.xml',
        'views/documents.xml'

    ],

    'license': 'LGPL-3',
    'price': 29,
    'currency': 'EUR',
    'installable': True,
    'auto_install': False,
    'application': False,
}
